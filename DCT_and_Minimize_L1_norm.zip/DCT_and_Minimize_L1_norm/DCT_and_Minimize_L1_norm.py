import numpy as np
import matplotlib.pyplot as plt
import cvxpy as cp
from scipy.fft import dct, idct

# パラメータ
N = 128
np.random.seed(0)
t = np.arange(N)

# 信号1: スパース（復元しやすい）
x_good = np.sin(2 * np.pi * t / N) + 0.3 * np.sin(4 * np.pi * t / N)

# 信号2: 非スパース（復元しにくい）
x_bad = np.random.randn(N)

# 観測マスク
mask_rate = 0.30 #ここで欠損率を変更
mask_bool = np.random.rand(N) < mask_rate
M = np.diag(mask_bool.astype(float))  # 対角マスク行列

# DCT行列
D = dct(np.eye(N), type=2, norm='ortho')

def reconstruct(x_true):
    #変数の定義#
    y_observed = M @ x_true     #y = M・x
    c = cp.Variable(N)          #cを未知の変数とする
    x_reconstructed = D.T @ c   #x = D^T・c

    #制約条件と目的関数を設定し、それらを使って定式化#
    constraints = [M @ x_reconstructed == y_observed]   #制約条件：y = M・x
    objective = cp.Minimize(cp.norm1(c))                #目的関数：変数cのL1ノルムを最小化する
    prob = cp.Problem(objective, constraints)           #ここまでに設定した目的関数と制約条件で問題を定式化

    #凸最適化問題を解く#
    prob.solve()

    return x_reconstructed.value, c.value   #xとcを返す


# 復元とDCT係数の取得
x_hat_good, c_hat_good = reconstruct(x_good)
x_hat_bad, c_hat_bad = reconstruct(x_bad)

# MSE計算
mse_good = np.mean((x_hat_good - x_good)**2)
mse_bad = np.mean((x_hat_bad - x_bad)**2)

# 描画
#元信号と復元信号
fig, axs = plt.subplots(2, 1, figsize=(10, 6), sharex=True)

axs[0].plot(t, x_good, label='True Signal')
axs[0].plot(t, x_hat_good, '--', label='Reconstructed')
axs[0].scatter(t[mask_bool], x_good[mask_bool], color='red', label='Observed', s=10)
axs[0].set_title(f'Easy to reconstruct (sparse) MSE = {mse_good:.4f}')
axs[0].legend()
axs[0].grid(True)

axs[1].plot(t, x_bad, label='True Signal')
axs[1].plot(t, x_hat_bad, '--', label='Reconstructed')
axs[1].scatter(t[mask_bool], x_bad[mask_bool], color='red', label='Observed', s=10)
axs[1].set_title(f'Hard to reconstruct (not sparse) MSE = {mse_bad:.4f}')
axs[1].legend()
axs[1].grid(True)

# 元信号のDCT係数 絶対値（スパース性の可視化）
figcoef, axscoef = plt.subplots(2, 1, figsize=(10, 6), sharex=True)
axscoef[0].stem(np.abs(dct(x_good, norm='ortho')), basefmt="--")
axscoef[0].set_title("org dct coefficient (sparse)")
axscoef[0].grid(True)

axscoef[1].stem(np.abs(dct(x_bad, norm='ortho')), basefmt="--")
axscoef[1].set_title("org dct coefficient (not sparse)")
axscoef[1].grid(True)

# 復元結果のDCT係数（元信号の係数と比較）
figcoef2, axscoef2 = plt.subplots(2, 1, figsize=(10, 6), sharex=True)
axscoef2[0].stem(np.abs(c_hat_good), basefmt="--")
axscoef2[0].set_title("reconstructed dct coefficient (sparse)")
axscoef2[0].grid(True)

axscoef2[1].stem(np.abs(c_hat_bad), basefmt="--")
axscoef2[1].set_title("reconstructed dct coefficient (not sparse)")
axscoef2[1].grid(True)

plt.tight_layout()
plt.show()