% DCTを使ったL1最適化による信号復元（スパース/非スパース信号）
% CVXを使用

clear; 
clc;

N = 128;
rng(0); % 再現性のための乱数初期化
t = 0:N-1;

% 信号1: スパース
x_good = sin(2 * pi * t / N) + 0.3 * sin(4 * pi * t / N);

% 信号2: 非スパース（ランダム）
x_bad = randn(1, N);

% 観測マスク
mask_rate = 0.30; %ここで欠損率を変更
mask_bool = rand(1, N) < mask_rate;
M = diag(double(mask_bool));  % 対角行列

% DCT行列
D = dct(eye(N));

% DCTベースの復元関数
function [x_rec, c] = reconstruct(x_true, M, D)
    y_obs = M * x_true(:);
    N = length(x_true);
    cvx_begin quiet
        variable c(N)
        x_est = D' * c;
        minimize(norm(c, 1))
        subject to
            M * x_est == y_obs
    cvx_end
    x_rec = x_est;
end

% 信号1の復元
[x_hat_good, c_hat_good] = reconstruct(x_good, M, D);
% 信号2の復元
[x_hat_bad, c_hat_bad] = reconstruct(x_bad, M, D);

% MSE計算
mse_good = mean((x_hat_good(:) - x_good(:)).^2);
mse_bad = mean((x_hat_bad(:) - x_bad(:)).^2);

% プロット
figure('Position', [100, 100, 1200, 800]);

% 信号と復元
subplot(3,2,1);
plot(t, x_good, 'b', 'DisplayName', 'True Signal'); hold on;
plot(t, x_hat_good, 'r--', 'DisplayName', 'Reconstructed');
scatter(t(mask_bool), x_good(mask_bool), 20, 'k', 'filled', 'DisplayName', 'Observed');
title(sprintf('Easy to reconstruct (sparse) (MSE = %.4f)', mse_good));
legend; grid on;

subplot(3,2,2);
plot(t, x_bad, 'b', 'DisplayName', 'True Signal'); hold on;
plot(t, x_hat_bad, 'r--', 'DisplayName', 'Reconstructed');
scatter(t(mask_bool), x_bad(mask_bool), 20, 'k', 'filled', 'DisplayName', 'Observed');
title(sprintf('Hard to reconstruct (not sparse) (MSE = %.4f)', mse_bad));
legend; grid on;

% DCT係数（元信号）
subplot(3,2,3);
stem(abs(dct(x_good)));%, 'ortho')));
title('org dct coefficient (sparse)'); grid on;

subplot(3,2,4);
stem(abs(dct(x_bad)));%, 'ortho')));
title('org dct coefficient (not sparse)'); grid on;

% 復元DCT係数
subplot(3,2,5);
stem(abs(c_hat_good));
title('reconstructed dct coefficient (sparse)'); grid on;

subplot(3,2,6);
stem(abs(c_hat_bad));
title('reconstructed dct coefficient (not sparse)'); grid on;
